/**
 * Automatically generated file. DO NOT MODIFY
 */
package dev.netlift.runtime;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "dev.netlift.runtime";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String NETLIFT_VERSION = "0.1.0-alpha.1";
}
